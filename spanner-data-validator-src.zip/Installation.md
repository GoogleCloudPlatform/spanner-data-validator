# Installation

The samples in this repo use Apache Beam with Java. The following prerequisites must be installed/configured for you to get started:

## Prerequisites

1. [Install Java](https://www.java.com/en/download/help/download_options.html)
2. [Install Maven](https://maven.apache.org/install.html)
3. [Install Git](https://github.com/git-guides/install-git)