package com.google.migration.dto;

public class RunConfig {
}
