package com.google.migration;

public class Constants {
  public static Integer PERCENTAGE_CALCULATION_DENOMINATOR = 100;
} // class Constants